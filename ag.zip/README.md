# Algoritmo Genetico

Aplicação no qual foi criado um algoritmo genetico para resolver uma função matematica para a disciplica de desenvolvimento de sistemas inteligentes, da faculdade.
